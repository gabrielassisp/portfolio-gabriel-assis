# Databricks notebook source
# MAGIC %md
# MAGIC # Lakehouse de vendas — Free Edition
# MAGIC Execute primeiro o Job publicado pelo bundle, ou instale o wheel e use as celulas abaixo.
# MAGIC Crie um volume gerenciado e envie os JSONL de data/sample para a pasta incoming.
# MAGIC A ponte tools/sync_gcs_to_volume.py permite trazer esses arquivos do GCS pelo seu PC.

# COMMAND ----------
# MAGIC %pip install /Volumes/workspace/default/vendas_input/packages/lakehouse_vendas-0.1.1-py3-none-any.whl

# COMMAND ----------
dbutils.library.restartPython()

# COMMAND ----------
dbutils.widgets.text('catalog', 'workspace')
dbutils.widgets.text('prefix', 'vendas_demo')
dbutils.widgets.text('input_path', '/Volumes/workspace/default/vendas_input/incoming/*.jsonl')

# COMMAND ----------
from vendas.databricks_job import run
run(spark, dbutils.widgets.get('catalog'), dbutils.widgets.get('prefix'), dbutils.widgets.get('input_path'))

# COMMAND ----------
catalog = dbutils.widgets.get('catalog')
prefix = dbutils.widgets.get('prefix')
from vendas.databricks_job import identifier
display(spark.table(f'{identifier(catalog)}.{identifier(prefix)}_gold.daily_sales'))
