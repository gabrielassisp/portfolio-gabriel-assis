"""Regras compartilhadas entre a demonstracao local e Databricks."""
