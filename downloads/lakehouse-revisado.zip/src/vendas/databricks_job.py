"""Spark + Delta em Unity Catalog. Sem pandas/collect de dados comerciais."""
import argparse
import json
import re

from vendas.domain import parse_for_spark


def identifier(value):
    if not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', value):
        raise ValueError('Catalogo/schema deve conter apenas letras, numeros e underscore')
    return value


def run(spark, catalog, prefix, input_path):
    from delta.tables import DeltaTable
    from pyspark.sql import functions as F, types as T, Window

    catalog, prefix = identifier(catalog), identifier(prefix)
    if not input_path.startswith('/Volumes/') or '..' in input_path.split('/'):
        raise ValueError('Use um caminho /Volumes/... de entrada')
    bronze = f'{catalog}.{prefix}_bronze.events'
    quarantine = f'{catalog}.{prefix}_bronze.quarantine'
    silver = f'{catalog}.{prefix}_silver.sales'
    gold = f'{catalog}.{prefix}_gold.daily_sales'
    for layer in ('bronze', 'silver', 'gold'):
        spark.sql(f'CREATE SCHEMA IF NOT EXISTS {catalog}.{prefix}_{layer}')
    raw = (spark.read.text(input_path).select(F.trim('value').alias('raw_json'))
           .filter(F.length('raw_json') > 0)
           .withColumn('raw_hash', F.sha2('raw_json', 256)).dropDuplicates(['raw_hash'])
           .withColumn('ingested_at', F.current_timestamp()))
    if raw.limit(1).count() == 0:
        raise ValueError('Entrada vazia: nenhuma tabela analitica foi publicada')

    def insert_raw(df, table):
        if not spark.catalog.tableExists(table):
            df.write.format('delta').mode('append').saveAsTable(table)
        else:
            (DeltaTable.forName(spark, table).alias('t').merge(df.alias('s'), 't.raw_hash = s.raw_hash')
             .whenNotMatchedInsertAll().execute())

    event_type = T.StructType([
        T.StructField('event_id', T.StringType()), T.StructField('sale_id', T.StringType()),
        T.StructField('source_version', T.LongType()), T.StructField('event_time', T.StringType()),
        T.StructField('op', T.StringType()), T.StructField('sale_date', T.StringType()),
        T.StructField('customer_id', T.StringType()), T.StructField('channel', T.StringType()),
        T.StructField('amount_cents', T.LongType()), T.StructField('payload_hash', T.StringType())])
    envelope = T.StructType([T.StructField('event', event_type), T.StructField('error', T.StringType())])
    normalizer = F.udf(parse_for_spark, T.StringType())

    def parsed(df):
        return df.withColumn('parsed', F.from_json(normalizer('raw_json'), envelope))

    insert_raw(raw, bronze)
    invalid = parsed(raw).filter(F.col('parsed.error').isNotNull()).select('raw_json', 'raw_hash', 'ingested_at')
    invalid_count = invalid.count()
    if invalid_count:
        insert_raw(invalid, quarantine)
        raise ValueError(f'{invalid_count} registros em quarentena; Silver nao atualizada')

    # Replay Bronze: recupera execucoes interrompidas e detecta conflitos historicos.
    # Evolucao futura: checkpoint para limitar varredura e manter registro de versoes.
    events = parsed(spark.table(bronze)).filter(F.col('parsed.error').isNull()).select('parsed.event.*')
    if events.groupBy('event_id').agg(F.countDistinct('payload_hash').alias('n')).filter('n > 1').limit(1).count():
        raise ValueError('event_id reutilizado com outro conteudo: publicacao bloqueada')
    business_columns = [c for c in events.columns if c not in ('event_id', 'payload_hash')]
    business = events.withColumn('business_hash', F.sha2(F.to_json(F.struct(*business_columns)), 256))
    if (business.groupBy('sale_id', 'source_version')
        .agg(F.countDistinct('business_hash').alias('n')).filter('n > 1').limit(1).count()):
        raise ValueError('Versoes conflitantes: publicacao bloqueada')
    latest = (events.withColumn('_rank', F.row_number().over(Window.partitionBy('sale_id')
              .orderBy(F.col('source_version').desc(), F.col('event_id').desc())))
              .filter('_rank = 1').drop('_rank'))
    if not spark.catalog.tableExists(silver):
        latest.write.format('delta').mode('append').saveAsTable(silver)
    else:
        (DeltaTable.forName(spark, silver).alias('t').merge(latest.alias('s'), 't.sale_id = s.sale_id')
         .whenMatchedUpdateAll(condition='s.source_version > t.source_version')
         .whenNotMatchedInsertAll().execute())
    # Tombstones ficam na Silver para impedir que eventos antigos ressuscitem vendas.
    # View evita sincronizar uma segunda copia materializada depois do MERGE.
    spark.sql(f'''CREATE OR REPLACE VIEW {gold} AS
        SELECT CAST(sale_date AS DATE) AS sale_date, channel,
               COUNT(*) AS sales_count,
               SUM(CAST(amount_cents AS DECIMAL(38,0))) AS revenue_cents,
               CAST(SUM(CAST(amount_cents AS DECIMAL(38,0))) / 100 AS DECIMAL(38,2)) AS revenue
        FROM {silver} WHERE op = 'UPSERT'
        GROUP BY CAST(sale_date AS DATE), channel''')
    metrics = {'input_rows': raw.count(), 'silver_rows': spark.table(silver).count(),
               'active_sales': spark.table(silver).filter("op = 'UPSERT'").count(), 'gold': gold}
    print(json.dumps(metrics))
    return metrics


def main():
    from pyspark.sql import SparkSession
    parser = argparse.ArgumentParser()
    parser.add_argument('--catalog', required=True)
    parser.add_argument('--prefix', default='vendas_demo')
    parser.add_argument('--input-path', required=True)
    args = parser.parse_args()
    run(SparkSession.builder.getOrCreate(), args.catalog, args.prefix, args.input_path)
