import argparse
import json
from pathlib import Path
from vendas.local import run_batch


def main():
    parser = argparse.ArgumentParser(description='Demo local com tabelas Delta e dados ficticios')
    parser.add_argument('--input', type=Path, default=Path('data/sample'))
    parser.add_argument('--output', type=Path, default=Path('output/lakehouse'))
    args = parser.parse_args()
    files = sorted(args.input.glob('*.jsonl')) if args.input.is_dir() else [args.input]
    if not files:
        parser.error('Nenhum arquivo JSONL encontrado')
    for file in files:
        result = run_batch(args.output, file)
        print(json.dumps(result, ensure_ascii=False, sort_keys=True))


if __name__ == '__main__':
    main()
