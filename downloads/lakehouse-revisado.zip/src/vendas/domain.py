"""Contrato de eventos. Valores monetarios em centavos, sem float."""
from datetime import date, datetime, timezone
from decimal import Decimal, InvalidOperation
import hashlib
import json


class QualityError(ValueError):
    pass


def digest(value):
    return hashlib.sha256(value.encode('utf-8')).hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(',', ':'), allow_nan=False)


def normalize(raw):
    try:
        event = json.loads(raw, parse_constant=lambda x: (_ for _ in ()).throw(ValueError(x)))
        if not isinstance(event, dict):
            raise ValueError('evento deve ser um objeto JSON')
        for field in ('event_id', 'sale_id', 'event_time', 'op'):
            if not isinstance(event.get(field), str) or not event[field].strip():
                raise ValueError(f'{field} obrigatorio')
        version = event.get('source_version')
        if type(version) is not int or not 1 <= version <= 2**63 - 1:
            raise ValueError('source_version deve ser inteiro positivo de 64 bits')
        operation = event['op'].strip().upper()
        if operation not in ('UPSERT', 'DELETE'):
            raise ValueError('op deve ser UPSERT ou DELETE')
        instant = datetime.fromisoformat(event['event_time'].replace('Z', '+00:00'))
        if instant.tzinfo is None:
            raise ValueError('event_time precisa de timezone')
        result = dict(event_id=event['event_id'].strip(), sale_id=event['sale_id'].strip(),
                      source_version=version, event_time=instant.astimezone(timezone.utc).isoformat(),
                      op=operation, sale_date=None, customer_id=None, channel=None, amount_cents=None)
        if operation == 'UPSERT':
            result['sale_date'] = date.fromisoformat(event['sale_date']).isoformat()
            for field in ('customer_id', 'channel'):
                if not isinstance(event.get(field), str) or not event[field].strip():
                    raise ValueError(f'{field} obrigatorio para UPSERT')
                result[field] = event[field].strip()
            result['channel'] = result['channel'].lower()
            if isinstance(event.get('amount'), bool):
                raise ValueError('amount invalido')
            amount = Decimal(str(event['amount']))
            if not amount.is_finite() or amount < 0 or amount.as_tuple().exponent < -2:
                raise ValueError('amount precisa ser nao negativo com ate duas casas decimais')
            cents = amount * 100
            if cents > 2**63 - 1:
                raise ValueError('amount excede limite de 64 bits')
            result['amount_cents'] = int(cents)
        result['payload_hash'] = digest(canonical(result))
        return result
    except (ValueError, KeyError, TypeError, InvalidOperation, OverflowError) as exc:
        raise QualityError(str(exc)) from exc


def parse_for_spark(raw):
    """UDF retorna JSON tipado; nunca inclui credenciais ou acesso a servicos."""
    try:
        return canonical({'event': normalize(raw), 'error': None})
    except QualityError as exc:
        return canonical({'event': None, 'error': str(exc)})


def validate_and_latest(events):
    """IDs imutaveis e versoes por venda nao podem ter conteudo conflitante."""
    ids, versions, latest = {}, {}, {}
    for event in events:
        ident = event['event_id']
        key = (event['sale_id'], event['source_version'])
        # event_id nao altera o estado comercial; comparar negocio sem o ID do envelope.
        business = canonical({k: v for k, v in event.items() if k not in ('event_id', 'payload_hash')})
        if ident in ids and ids[ident] != event['payload_hash']:
            raise QualityError(f'event_id reutilizado com outro conteudo: {ident}')
        if key in versions and versions[key] != business:
            raise QualityError(f'versao conflitante para venda {key}')
        ids[ident], versions[key] = event['payload_hash'], business
        previous = latest.get(event['sale_id'])
        if previous is None or (event['source_version'], ident) > (previous['source_version'], previous['event_id']):
            latest[event['sale_id']] = event
    return list(latest.values())


def summarize(events):
    groups = {}
    for event in events:
        if event['op'] == 'DELETE':
            continue
        key = (event['sale_date'], event['channel'])
        row = groups.setdefault(key, dict(sale_date=key[0], channel=key[1], sales_count=0, revenue_cents=0))
        row['sales_count'] += 1
        row['revenue_cents'] += event['amount_cents']
    return [groups[k] for k in sorted(groups)]
