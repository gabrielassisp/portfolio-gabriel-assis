"""Demonstracao com Delta real via delta-rs; sem Spark nem conta cloud."""
from datetime import datetime, timezone
from pathlib import Path
import json
import pyarrow as pa
from deltalake import DeltaTable, write_deltalake
from vendas.domain import QualityError, digest, normalize, validate_and_latest, summarize

RAW_SCHEMA = pa.schema([('raw_hash', pa.string()), ('raw_json', pa.string()),
                        ('batch_id', pa.string()), ('ingested_at', pa.string())])
EVENT_SCHEMA = pa.schema([(k, pa.string()) for k in ('event_id', 'sale_id')] +
                        [('source_version', pa.int64())] +
                        [(k, pa.string()) for k in ('event_time', 'op', 'sale_date', 'customer_id', 'channel')] +
                        [('amount_cents', pa.int64()), ('payload_hash', pa.string())])
GOLD_SCHEMA = pa.schema([('sale_date', pa.string()), ('channel', pa.string()),
                         ('sales_count', pa.int64()), ('revenue_cents', pa.int64())])


def read(path):
    return DeltaTable(str(path)).to_pyarrow_dataset().to_table(use_threads=False).to_pylist() if (path / '_delta_log').exists() else []


def merge_insert(path, rows):
    if not rows:
        return
    source = pa.Table.from_pylist(rows, schema=RAW_SCHEMA)
    if not (path / '_delta_log').exists():
        write_deltalake(str(path), source)
    else:
        (DeltaTable(str(path)).merge(source, 't.raw_hash = s.raw_hash',
                                    source_alias='s', target_alias='t')
         .when_not_matched_insert_all().execute())


def run_batch(root, file):
    root, file = Path(root), Path(file)
    raw = list(dict.fromkeys(line.strip() for line in file.read_text(encoding='utf-8').splitlines() if line.strip()))
    if not raw:
        raise QualityError('Entrada vazia: nenhuma tabela foi publicada')
    now = datetime.now(timezone.utc).isoformat()
    rows = [dict(raw_hash=digest(line), raw_json=line, batch_id=file.name, ingested_at=now) for line in raw]
    merge_insert(root / 'bronze/events', rows)
    invalid = []
    for row in rows:
        try:
            normalize(row['raw_json'])
        except QualityError:
            invalid.append(row)
    merge_insert(root / 'quarantine/events', invalid)
    if invalid:
        raise QualityError(f'{len(invalid)} eventos invalidos; Silver/Gold preservadas. Consulte quarantine.')
    # Replay de todo o historico Bronze garante recuperacao apos queda entre etapas.
    # A demo e intencionalmente pequena; isto nao e um leitor incremental de arquivos em escala.
    events = []
    for row in read(root / 'bronze/events'):
        try:
            events.append(normalize(row['raw_json']))
        except QualityError:
            pass  # rejeitados permanecem auditaveis; nao participam da publicacao.
    latest = validate_and_latest(events)
    source = pa.Table.from_pylist(latest, schema=EVENT_SCHEMA)
    silver = root / 'silver/sales'
    if not (silver / '_delta_log').exists():
        write_deltalake(str(silver), source)
    elif latest:
        (DeltaTable(str(silver)).merge(source, 't.sale_id = s.sale_id',
                                     source_alias='s', target_alias='t')
         .when_matched_update_all(predicate='s.source_version > t.source_version')
         .when_not_matched_insert_all().execute())
    gold = summarize(read(silver))
    write_deltalake(str(root / 'gold/daily_sales'), pa.Table.from_pylist(gold, schema=GOLD_SCHEMA), mode='overwrite')
    return dict(batch_id=file.name, input_rows=len(rows), silver_rows=len(read(silver)),
                active_sales=sum(r['sales_count'] for r in gold),
                revenue_cents=sum(r['revenue_cents'] for r in gold), gold=gold)
