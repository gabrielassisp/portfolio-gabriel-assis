"""Ponte externa: GCS -> Unity Catalog Volume; util para Databricks Free Edition.

Executar no PC/runner autenticado, nao dentro do compute Free Edition.
Nao cria buckets/volumes, nao altera IAM, nao embute secrets.
"""
import argparse
from io import BytesIO
import re
from google.cloud import storage
from databricks.sdk import WorkspaceClient
from databricks.sdk.errors import NotFound


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--bucket', required=True)
    parser.add_argument('--prefix', default='incoming/')
    parser.add_argument('--volume-path', required=True)
    parser.add_argument('--profile', default='DEFAULT')
    args = parser.parse_args()
    if not re.fullmatch(r'/Volumes/[\w-]+/[\w-]+/[\w-]+/incoming', args.volume_path):
        parser.error('volume-path esperado: /Volumes/catalog/schema/volume/incoming')
    client = storage.Client()
    workspace = WorkspaceClient(profile=args.profile)
    workspace.files.create_directory(args.volume_path)
    copied, skipped = 0, 0
    for blob in client.list_blobs(args.bucket, prefix=args.prefix):
        if not blob.name.endswith('.jsonl'):
            continue
        if blob.size is None or blob.size > 10 * 1024 * 1024:
            raise ValueError('Ponte demonstrativa limitada a 10 MiB por arquivo')
        # Codificar nome completo evita colisao de arquivos de subdiretorios diferentes.
        import hashlib
        key = hashlib.sha256((args.bucket + '/' + blob.name).encode()).hexdigest()[:24]
        path = f'{args.volume_path}/{key}-g{blob.generation}.jsonl'
        try:
            workspace.files.get_metadata(path)
            skipped += 1
            continue
        except NotFound:
            pass
        data = blob.download_as_bytes(if_generation_match=int(blob.generation))
        workspace.files.upload(path, BytesIO(data), overwrite=False)
        copied += 1
    print(f'Arquivos copiados: {copied}; ja presentes: {skipped}')


if __name__ == '__main__':
    main()
