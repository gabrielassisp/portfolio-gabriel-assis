# Lakehouse de vendas: qualidade, versões e replay

Projeto demonstrativo de Gabriel Assis, desenvolvido com apoio de IA e validado localmente e em um workspace Databricks Free Edition. Todos os eventos são fictícios. Esta cópia foi preparada para revisão antes de divulgação; não altera a visibilidade do repositório privado.

## O problema
Correções, exclusões e eventos atrasados não podem duplicar a receita ou restaurar uma venda excluída. O projeto preserva a entrada em Bronze, valida o contrato e mantém o estado mais recente por venda em Silver. A Gold publica indicadores das vendas ativas.

## Executar localmente
Requer Python 3.11 ou 3.13. A versão local usa Delta Lake via delta-rs e PyArrow; não precisa de Java, Spark, Docker ou conta cloud.

```powershell
python -m venv .venv
.\.venv\Scripts\python -m pip install -e ".[local,dev]"
.\.venv\Scripts\python -m pytest -q
.\.venv\Scripts\vendas-demo
.\.venv\Scripts\vendas-demo
```

Linux/macOS: use `.venv/bin/python` e `.venv/bin/vendas-demo`.

A segunda execução reprocessa os mesmos arquivos. Resultado final esperado: **R$ 250,00, três vendas ativas e quatro linhas Silver**. Os arquivos Delta são gerados em `output/lakehouse/`. O lote inválido está separado em `data/invalid/` e é exercitado pelos testes.

## Arquitetura
```mermaid
flowchart LR
 A[BigQuery Sandbox] --> B[Exportação manual JSON]
 B --> C[Volume Databricks]
 C --> D[Bronze Delta]
 D --> E{Qualidade e conflitos}
 E -->|válido| F[Silver: MERGE por venda e versão]
 E -->|inválido| Q[Quarentena e bloqueio]
 F --> G[Gold: vendas ativas]
```

O runner local reproduz os cenários com tabelas Delta. A implementação cloud usa PySpark/Delta. O fluxo BigQuery → Databricks é manual; o Job não extrai o GCP automaticamente.

## Resultados e decisões
- Receita inicial de R$ 350,00; após correção, exclusão e inclusão: R$ 250,00.
- Uma linha por venda na Silver; tombstones impedem a reativação por eventos antigos.
- Dinheiro normalizado em centavos inteiros.
- Eventos inválidos são rejeitados antes de atualizar o estado comercial.
- Replay mantém o resultado comercial.
- CI em Python 3.11/3.13 executa testes, build do wheel e demo/replay; não implanta no Databricks.

Veja [decisões](docs/DECISIONS.md), [estudo de caso](docs/CASE_STUDY.md), [evidências](docs/PUBLIC_VALIDATION.md) e [roteiro de demonstração](docs/DEMO.md).

## Estrutura
- `src/vendas/domain.py`: normalização e contrato de eventos.
- `src/vendas/local.py`: runner Delta local.
- `src/vendas/databricks_job.py`: processamento PySpark.
- `tests/`: testes de regras, Delta local e CLI.
- `.github/workflows/ci.yml`: integração contínua sem secrets.
- `notebooks/`: notebooks sem outputs ou metadados de execução privados.
- `infra/`: alternativa Terraform/GCS preparada, **não implantada**.

## Execução cloud e custo
O laboratório foi executado em BigQuery Sandbox e Databricks Free Edition em 15/11/2026. URLs privadas e identificadores da conta foram retirados desta cópia. Antes de executar o SQL, substitua `SEU_PROJETO_GCP` pelo seu projeto e confira permissões e cotas. Não ative faturamento ou aplique Terraform para reproduzir a demo local. Uma conta gratuita não é garantia universal de custo zero em todos os serviços.

## Limites
São oito eventos sintéticos, sem benchmark, SLA ou dados reais. A Bronze é relida por completo; não há checkpoint de arquivos ou transação global entre camadas. O CI não executa Spark no workspace. GCS/Terraform e a automação da transferência permanecem como alternativas não validadas.

## Contato
[GitHub](https://github.com/gabrielassisp) · [LinkedIn](https://www.linkedin.com/in/gabriel-assispereira)
