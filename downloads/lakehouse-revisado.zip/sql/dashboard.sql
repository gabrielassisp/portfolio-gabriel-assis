-- Ajuste workspace se seu catalogo tiver outro nome.
-- Faturamento e vendas por dia/canal
SELECT sale_date, channel, sales_count, revenue
FROM workspace.vendas_demo_gold.daily_sales
ORDER BY sale_date, channel;

-- KPIs gerais
SELECT SUM(sales_count) AS active_sales, SUM(revenue) AS revenue,
       SUM(revenue) / NULLIF(SUM(sales_count), 0) AS average_ticket
FROM workspace.vendas_demo_gold.daily_sales;

-- Vendas excluidas preservadas como tombstones (nao contam na Gold)
SELECT sale_id, source_version, event_time
FROM workspace.vendas_demo_silver.sales
WHERE op = 'DELETE';
