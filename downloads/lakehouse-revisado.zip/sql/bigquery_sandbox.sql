-- Dados fictícios: projeto sem conta de faturamento, BigQuery Sandbox.
-- DDL + SELECT; não utiliza DML nem streaming.
CREATE SCHEMA IF NOT EXISTS `SEU_PROJETO_GCP.portfolio_vendas`
OPTIONS(location='US', default_table_expiration_days=60);

CREATE TABLE IF NOT EXISTS `SEU_PROJETO_GCP.portfolio_vendas.raw_events`
OPTIONS(description='Eventos fictícios compartilhados com o lakehouse Databricks; demonstração de portfólio.') AS
SELECT raw_json FROM UNNEST([
  r'''{"event_id":"e1","sale_id":"v1","source_version":1,"event_time":"2026-11-01T12:00:00Z","op":"UPSERT","sale_date":"2026-11-01","customer_id":"c1","channel":"Site","amount":"100.00"}''',
  r'''{"event_id":"e2","sale_id":"v2","source_version":1,"event_time":"2026-11-01T12:10:00Z","op":"UPSERT","sale_date":"2026-11-01","customer_id":"c2","channel":"Loja","amount":"200.00"}''',
  r'''{"event_id":"e3","sale_id":"v3","source_version":1,"event_time":"2026-11-01T12:20:00Z","op":"UPSERT","sale_date":"2026-11-01","customer_id":"c3","channel":"Site","amount":"50.00"}''',
  r'''{"event_id":"e4","sale_id":"v1","source_version":2,"event_time":"2026-11-02T12:00:00Z","op":"UPSERT","sale_date":"2026-11-01","customer_id":"c1","channel":"Site","amount":"120.00"}''',
  r'''{"event_id":"e5","sale_id":"v2","source_version":2,"event_time":"2026-11-02T12:10:00Z","op":"DELETE"}''',
  r'''{"event_id":"e6","sale_id":"v4","source_version":1,"event_time":"2026-11-02T12:20:00Z","op":"UPSERT","sale_date":"2026-11-02","customer_id":"c4","channel":"Parceiro","amount":"80.00"}''',
  r'''{"event_id":"e7","sale_id":"v2","source_version":1,"event_time":"2026-11-01T12:10:00Z","op":"UPSERT","sale_date":"2026-11-01","customer_id":"c2","channel":"Loja","amount":"200.00"}''',
  r'''{"event_id":"e8","sale_id":"v1","source_version":1,"event_time":"2026-11-01T12:00:00Z","op":"UPSERT","sale_date":"2026-11-01","customer_id":"c1","channel":"Site","amount":"100.00"}'''
]) AS raw_json;

-- Mesmas regras de versão e exclusão da implementação Delta.
WITH parsed AS (
  SELECT JSON_VALUE(raw_json, '$.sale_id') AS sale_id,
         SAFE_CAST(JSON_VALUE(raw_json, '$.source_version') AS INT64) AS source_version,
         JSON_VALUE(raw_json, '$.event_id') AS event_id,
         JSON_VALUE(raw_json, '$.op') AS op,
         SAFE_CAST(JSON_VALUE(raw_json, '$.amount') AS NUMERIC) AS amount
  FROM `SEU_PROJETO_GCP.portfolio_vendas.raw_events`
), latest AS (
  SELECT * FROM parsed
  QUALIFY ROW_NUMBER() OVER(PARTITION BY sale_id ORDER BY source_version DESC, event_id DESC)=1
)
SELECT COUNT(*) AS silver_rows,
       COUNTIF(op='DELETE') AS tombstones,
       COUNTIF(op='UPSERT') AS active_sales,
       SUM(IF(op='UPSERT', amount, 0)) AS revenue
FROM latest;
-- Resultado esperado: 4 | 1 | 3 | 250.00
-- Para exportar a fonte: SELECT raw_json FROM `SEU_PROJETO_GCP.portfolio_vendas.raw_events`;
