terraform {
  required_version = ">= 1.6"
  required_providers {
    google = {
      source  = "hashicorp/google"
      version = "~> 6.0"
    }
  }
}

provider "google" {
  project = var.project_id
  region  = var.region
}

variable "project_id" { type = string }
variable "bucket_name" { type = string }
variable "region" {
  type    = string
  default = "us-central1"
}

# Nao cria workspace Databricks, clusters nem recursos de producao.
resource "google_storage_bucket" "landing" {
  name                        = var.bucket_name
  location                    = var.region
  uniform_bucket_level_access = true
  public_access_prevention    = "enforced"
  force_destroy               = false
  versioning { enabled = true }
  labels = {
    purpose = "portfolio"
    project = "lakehouse-vendas"
  }
}

resource "google_service_account" "bridge" {
  account_id   = "vendas-volume-bridge"
  display_name = "Leitura GCS para demonstracao de vendas"
}

resource "google_storage_bucket_iam_member" "reader" {
  bucket = google_storage_bucket.landing.name
  role   = "roles/storage.objectViewer"
  member = "serviceAccount:${google_service_account.bridge.email}"
}

output "bucket_uri" { value = "gs://${google_storage_bucket.landing.name}" }
output "bridge_service_account" { value = google_service_account.bridge.email }
