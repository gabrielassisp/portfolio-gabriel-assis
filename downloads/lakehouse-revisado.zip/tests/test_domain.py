import json
import pytest
from vendas.domain import normalize, QualityError, validate_and_latest, summarize, parse_for_spark


def event(**kwargs):
    row = dict(event_id='e1', sale_id='v1', source_version=1, event_time='2026-11-01T12:00:00Z',
               op='UPSERT', sale_date='2026-11-01', customer_id='c1', channel=' SITE ', amount='0.10')
    row.update(kwargs)
    return json.dumps(row)


def test_money_is_exact_and_channel_normalized():
    row = normalize(event())
    assert row['amount_cents'] == 10
    assert row['channel'] == 'site'
    assert normalize(event(amount='0.20'))['amount_cents'] + row['amount_cents'] == 30


@pytest.mark.parametrize('change', [dict(amount='-1'), dict(amount='1.001'), dict(amount='NaN'),
    dict(amount=True), dict(source_version=True), dict(source_version=0), dict(source_version=2**63),
    dict(event_time='2026-11-01T12:00:00'), dict(sale_date='2026-02-30'), dict(channel=''),
    dict(op='DROP'), dict(sale_id=None), dict(amount='100000000000000000000000')])
def test_reject_invalid_events(change):
    with pytest.raises(QualityError):
        normalize(event(**change))


@pytest.mark.parametrize('raw', ['broken', '[]', 'null', '{"x":NaN}'])
def test_invalid_json_is_quarantinable(raw):
    assert json.loads(parse_for_spark(raw))['error']


def test_version_controls_order_not_arrival_time():
    old = normalize(event())
    new = normalize(event(event_id='e2', source_version=2, amount='120.00'))
    assert validate_and_latest([new, old])[0]['amount_cents'] == 12000


def test_tombstone_prevents_resurrection():
    old = normalize(event())
    deleted = normalize(event(event_id='e2', source_version=2, op='DELETE'))
    latest = validate_and_latest([deleted, old])
    assert latest[0]['op'] == 'DELETE'
    assert summarize(latest) == []


def test_reused_event_id_fails():
    with pytest.raises(QualityError, match='event_id'):
        validate_and_latest([normalize(event()), normalize(event(amount='20.00'))])


def test_conflicting_version_fails_even_with_different_event_ids():
    with pytest.raises(QualityError, match='versao'):
        validate_and_latest([normalize(event()), normalize(event(event_id='e2', amount='20.00'))])


def test_duplicate_business_version_with_other_envelope_is_accepted():
    assert len(validate_and_latest([normalize(event()), normalize(event(event_id='e2'))])) == 1


def test_spark_wrapper_uses_same_normalization():
    assert json.loads(parse_for_spark(event()))['event'] == normalize(event())
