import json
from pathlib import Path
import pytest
from deltalake import DeltaTable
from vendas.local import run_batch, read
from vendas.domain import QualityError

DATA = Path(__file__).resolve().parents[1] / 'data'


def load_all(root):
    return [run_batch(root, p) for p in sorted((DATA / 'sample').glob('*.jsonl'))]


def test_full_scenario_and_replay_are_idempotent(tmp_path):
    results = load_all(tmp_path)
    assert [r['revenue_cents'] for r in results] == [35000, 25000, 25000]
    assert [r['active_sales'] for r in results] == [3, 3, 3]
    before = sorted(read(tmp_path / 'silver/sales'), key=lambda r: r['sale_id'])
    raw_count = len(read(tmp_path / 'bronze/events'))
    assert load_all(tmp_path)[-1]['revenue_cents'] == 25000
    assert sorted(read(tmp_path / 'silver/sales'), key=lambda r: r['sale_id']) == before
    assert len(read(tmp_path / 'bronze/events')) == raw_count == 8
    assert next(r for r in before if r['sale_id'] == 'v2')['op'] == 'DELETE'


def test_invalid_batch_preserves_published_delta_versions(tmp_path):
    load_all(tmp_path)
    silver = tmp_path / 'silver/sales'
    gold = tmp_path / 'gold/daily_sales'
    versions = (DeltaTable(str(silver)).version(), DeltaTable(str(gold)).version())
    with pytest.raises(QualityError):
        run_batch(tmp_path, DATA / 'invalid/negative.jsonl')
    assert (DeltaTable(str(silver)).version(), DeltaTable(str(gold)).version()) == versions
    assert len(read(tmp_path / 'quarantine/events')) == 1
    assert load_all(tmp_path)[-1]['revenue_cents'] == 25000


def test_conflicting_historical_event_blocks_publication(tmp_path):
    load_all(tmp_path)
    changed = json.loads((DATA / 'sample/001_initial.jsonl').read_text().splitlines()[0])
    changed['amount'] = '999.00'
    file = tmp_path / 'conflict.jsonl'
    file.write_text(json.dumps(changed), encoding='utf-8')
    before = DeltaTable(str(tmp_path / 'silver/sales')).version()
    with pytest.raises(QualityError, match='event_id|versao'):
        run_batch(tmp_path, file)
    assert DeltaTable(str(tmp_path / 'silver/sales')).version() == before


def test_recover_after_failure_between_silver_and_gold(tmp_path, monkeypatch):
    import vendas.local as local
    run_batch(tmp_path, DATA / 'sample/001_initial.jsonl')
    original = local.write_deltalake

    def fail_gold(path, *args, **kwargs):
        if Path(path).parts[-2:] == ('gold', 'daily_sales'):
            raise RuntimeError('queda simulada antes da Gold')
        return original(path, *args, **kwargs)

    with monkeypatch.context() as patch:
        patch.setattr(local, 'write_deltalake', fail_gold)
        with pytest.raises(RuntimeError, match='queda simulada'):
            run_batch(tmp_path, DATA / 'sample/002_changes.jsonl')
    # Silver mudou, Gold local ainda antiga: a reexecucao deve recuperar a Gold.
    result = run_batch(tmp_path, DATA / 'sample/002_changes.jsonl')
    assert result['revenue_cents'] == 25000


def test_duplicate_lines_inside_batch_do_not_duplicate_sales(tmp_path):
    raw = (DATA / 'sample/001_initial.jsonl').read_text().splitlines()[0]
    file = tmp_path / 'duplicates.jsonl'
    file.write_text(raw + '\n' + raw, encoding='utf-8')
    result = run_batch(tmp_path, file)
    assert result['active_sales'] == 1
    assert len(read(tmp_path / 'bronze/events')) == 1


def test_empty_batch_fails_without_creating_tables(tmp_path):
    file = tmp_path / 'empty.jsonl'
    file.write_text('\n  \n', encoding='utf-8')
    with pytest.raises(QualityError, match='vazia'):
        run_batch(tmp_path / 'lake', file)
    assert not (tmp_path / 'lake/bronze/events').exists()
