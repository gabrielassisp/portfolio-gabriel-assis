import ast
from pathlib import Path
import yaml
import pytest
from vendas.databricks_job import identifier

ROOT = Path(__file__).resolve().parents[1]


def test_python_syntax_without_importing_cloud_dependencies():
    for folder in ('src', 'tools', 'notebooks', 'tests'):
        for path in (ROOT / folder).rglob('*.py'):
            ast.parse(path.read_text(encoding='utf-8'), filename=str(path))


def test_bundle_runs_single_serverless_job_without_schedule():
    config = yaml.safe_load((ROOT / 'databricks.yml').read_text())
    job = config['resources']['jobs']['vendas']
    assert job['max_concurrent_runs'] == 1
    assert 'schedule' not in job
    assert job['tasks'][0]['environment_key'] == 'default'
    assert job['tasks'][0]['python_wheel_task']['entry_point'] == 'vendas-cloud'


@pytest.mark.parametrize('name', ['x; DROP TABLE sales', 'a.b', 'a-b', '', '../x'])
def test_sql_identifiers_are_validated(name):
    with pytest.raises(ValueError):
        identifier(name)
