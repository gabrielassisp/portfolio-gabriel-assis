import json
import os
from pathlib import Path
import subprocess
import sys


def test_cli_replay_exits_cleanly_and_preserves_totals(tmp_path):
    root = Path(__file__).resolve().parents[1]
    command = [sys.executable, '-m', 'vendas.cli', '--input', str(root / 'data/sample'), '--output', str(tmp_path / 'delta')]
    env = dict(os.environ, PYTHONUTF8='1')
    for attempt in range(2):
        result = subprocess.run(command, capture_output=True, text=True, timeout=60, env=env)
        assert result.returncode == 0, result.stderr
        rows = [json.loads(line) for line in result.stdout.splitlines()]
        assert len(rows) == 3
        assert rows[-1]['revenue_cents'] == 25000
        assert rows[-1]['active_sales'] == 3
        assert rows[-1]['silver_rows'] == 4
