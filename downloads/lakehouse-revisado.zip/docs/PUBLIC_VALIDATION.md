# Evidências e reprodução

## Histórico
- 15/11/2026: notebook PySpark e Job Databricks executados. Registro histórico: Succeeded em 2min56s, resultado final de R$ 250,00 e replay conferido. Não representa SLA.
- 22/11/2026: 38 testes locais passaram em 11,44s; nova demo/replay preservou R$ 250,00, três vendas ativas e quatro linhas Silver.
- Em 22/11/2026, os jobs Python 3.11 e 3.13 do workflow `44863230990` foram consultados no GitHub e ambos estavam concluídos com sucesso. O link exige acesso enquanto o repositório estiver privado.

As URLs do workspace e identificadores privados foram removidos desta cópia. Registros históricos descrevem a execução original; não comprovam a execução desta cópia sanitizada, cujo resultado deve constar em `REVISAO_PUBLICACAO.txt` após os checks.

## Como conferir
1. Instale o pacote em um ambiente virtual com as dependências local/dev.
2. Execute `python -m pytest -q`.
3. Execute `vendas-demo` duas vezes no mesmo diretório de saída.
4. Confira o resultado final: 25000 centavos, três vendas ativas, quatro linhas Silver.

Os dados são fictícios. A validação local não substitui a execução PySpark em um workspace próprio.
