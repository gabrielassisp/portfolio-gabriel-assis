# Execução sem cobrança: BigQuery Sandbox + Databricks Free Edition

A conta GCP consultada no projeto `SEU_PROJETO_GCP` não tem faturamento vinculado. Mantivemos essa condição.

## Arquitetura executada

1. O SQL em `sql/bigquery_sandbox.sql` cria o dataset `portfolio_vendas`, com expiração padrão de tabelas em 60 dias, e a tabela `raw_events` com oito eventos fictícios.
2. A consulta SQL de validação seleciona a maior versão por venda, preservando exclusões. Resultado conferido no GCP: 4 registros, 1 tombstone, 3 vendas ativas, receita 250.
3. A fonte é exportada com `SELECT raw_json FROM SEU_PROJETO_GCP.portfolio_vendas.raw_events ORDER BY JSON_VALUE(raw_json, '$.event_id')` e download local em JSON pelo console.
4. Removemos apenas o envelope `raw_json` da exportação. Os oito eventos foram comparados aos arquivos originais; hashes e procedência estão em `data/gcp_export/provenance.json`.
5. Execute primeiro `03_demo_serverless.ipynb` para disponibilizar o pacote wheel no Volume. O notebook `04_gcp_sandbox_para_databricks.ipynb` transfere esse conteúdo ao Volume, verifica o hash e executa a pipeline em schemas separados `vendas_gcp_bronze`, `vendas_gcp_silver`, `vendas_gcp_gold`.

A transferência é manual por arquivo/notebook. Não há agendamento da extração, conector direto BigQuery–Databricks ou promessa de tempo real. O objetivo desta versão é demonstrar processamento e reconciliação entre dois ambientes cloud sem ativar faturamento.

## Acesso

- GCP: https://console.cloud.google.com/bigquery
- Databricks: WORKSPACE_DATABRICKS_PRIVADO
- Job de demonstração: WORKSPACE_DATABRICKS_PRIVADO

## Limites

- BigQuery Sandbox tem cotas próprias, expiração automática de recursos e restrições a DML/streaming. Consulte https://docs.cloud.google.com/bigquery/docs/sandbox.
- Databricks Free Edition também tem cotas próprias; não é infraestrutura com SLA de produção.
- A alternativa GCS em `infra/` é opcional, não aplicada. Ela exige conta de faturamento mesmo quando o uso cabe no Free Tier. Não ativar faturamento nem aplicar Terraform para reproduzir esta demonstração gratuita.
- Esta cópia está preparada para revisão; a publicação e a mudança de visibilidade ainda não foram realizadas.


Nota da versão para divulgação: WORKSPACE_DATABRICKS_PRIVADO indica um endereço removido. Use seu próprio workspace; este texto preserva o histórico da execução original.
