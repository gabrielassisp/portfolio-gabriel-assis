# Demonstração em três minutos

Roteiro para apresentar o projeto em entrevista ou gravar um vídeo. Os links remetem a execuções conferidas em 15/11/2026; confira o acesso antes da apresentação. Não é necessário ativar faturamento.

## Preparação

- Abra o [estudo de caso](CASE_STUDY.md), o [CI aprovado](https://github.com/gabrielassisp/lakehouse-vendas-gcp-databricks/actions/runs/43784755626), o [Job concluído](WORKSPACE_DATABRICKS_PRIVADO) e o [notebook da transferência](WORKSPACE_DATABRICKS_PRIVADO).
- Se quiser produzir uma execução nova, siga [FREE_SANDBOX.md](FREE_SANDBOX.md) e conclua-a antes da gravação. Os tempos de inicialização variam; o roteiro usa resultados já concluídos.
- O repositório é privado. Para mostrar o código a terceiros, compartilhe a tela ou decida separadamente como dar acesso ao material.

## 0:00–0:30 — Problema e arquitetura

“O objetivo é manter o total de vendas correto após correções, exclusões e eventos atrasados. Usei eventos fictícios no BigQuery Sandbox, exportei o JSON manualmente e processei a entrada no Databricks em camadas Bronze, Silver e Gold.”

Mostre o diagrama do estudo de caso. Diga que a transferência é manual e que o Job executa a demonstração de processamento.

## 0:30–1:10 — Regra de negócio

Mostre a tabela de cenários no README: receita inicial de R$ 350,00; após correção/exclusão/inclusão, R$ 250,00. Explique a granularidade: uma linha por venda na Silver, incluindo o marcador de exclusão.

“A ordem é definida pela versão da venda. Um evento antigo não pode atualizar uma versão mais nova, inclusive quando essa versão representa uma exclusão.”

## 1:10–1:50 — Prova de confiabilidade

No resultado do notebook 03 ou do Job, mostre:

1. Receita de R$ 250,00 e três vendas ativas.
2. `PASS: replay idempotente [8, 4] [8, 4]`.
3. Bloqueio do lote inválido e comparação da Silver antes/depois.

“A Bronze conserva a entrada. Se a validação falha, registro a rejeição e interrompo a atualização da Silver. A reexecução dos mesmos dados não duplica o estado comercial.”

## 1:50–2:25 — Execução e CI

Mostre o Job com status Succeeded e o workflow aprovado em Python 3.11/3.13. A execução observada do Job durou 2min56s; não apresente esse tempo como SLA.

“O CI valida regras e tabelas Delta locais, constrói o pacote e roda a demo duas vezes. O teste do Spark foi feito no workspace. O deploy cloud ainda é manual.”

## 2:25–3:00 — GCP e decisões

Mostre a mensagem PASS no notebook 04, que processou os oito eventos exportados do BigQuery, e o hash de procedência em `data/gcp_export/provenance.json`.

“Mantive o projeto sem faturamento GCP. Isso limita a integração: a transferência é por exportação e upload. As próximas melhorias seriam autenticar e automatizar essa etapa e persistir métricas; checkpoints fariam sentido com um histórico maior.”

## Perguntas para você praticar

- O que torna o replay idempotente? Qual a diferença entre deduplicar a entrada e preservar o estado comercial?
- Por que a exclusão continua na Silver?
- O que acontece se dois eventos têm a mesma venda e versão, mas conteúdos diferentes?
- Qual parte do fluxo é incremental e qual parte relê o histórico?
- O que os 38 testes comprovam e o que depende da validação no workspace?
- O que você precisaria mudar antes de usar o desenho com APIs e dados reais?

As respostas estão em [DECISIONS.md](DECISIONS.md). Revise-as no código antes de apresentar.


Nota da versão para divulgação: WORKSPACE_DATABRICKS_PRIVADO indica um endereço removido. Use seu próprio workspace; este texto preserva o histórico da execução original.
