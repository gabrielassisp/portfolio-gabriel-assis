# Evidências de validação — 15/11/2026

## Databricks Free Edition: executado e conferido

Notebook: WORKSPACE_DATABRICKS_PRIVADO

- Volume gerenciado `workspace.default.vendas_input` e instalação do wheel 0.1.1.
- Pipeline PySpark/Delta com schemas Bronze/Silver/Gold e view `workspace.vendas_demo_gold.daily_sales`.
- Três lotes: 3 vendas iniciais, alteração/exclusão/inclusão, chegada de versões antigas.
- Estado final confirmado: 4 registros Silver, 1 tombstone, 3 vendas ativas, receita de R$ 250,00.
- Replay: contagens Bronze/Silver mantidas em `[8, 4]` antes e depois.
- Lote inválido: `PASS: qualidade bloqueou a publicação: 1 registros em quarentena; Silver nao atualizada`.
- Comparação das linhas antes/depois confirmou Silver preservada após falha de qualidade.
- `errorifexists` não é suportado por esse runtime: gravação inicial ajustada para append, dentro da verificação de ausência da tabela. Concorrência de escritores está fora das garantias desta demonstração.

## Testes locais

- Python 3.13.15, Windows; deltalake 1.6.6 e PyArrow 23.0.1.
- 38 testes aprovados, incluindo CLI executada duas vezes em subprocessos independentes.
- Regras: validação, tombstones, eventos atrasados, identidade/versões conflitantes, replay, preservação após lote inválido e recuperação após falha antes da Gold.
- Teste do CLI verifica código de saída, receita, quantidade de vendas e repetição do mesmo diretório.

## GitHub Actions

- Repositório próprio criado: https://github.com/gabrielassisp/lakehouse-vendas-gcp-databricks (privado).
- Primeira execução: 37 testes e build passaram em Python 3.11/3.13; o CLI abortou ao encerrar no Linux após emitir os resultados esperados.
- Leitura Arrow da demo ajustada para `use_threads=False`, com teste adicional de encerramento do processo. Correção publicada no commit `327064ce39020aa797eb2d59b443107f2a82b826`.
- CI corrigido conferido: SUCCESS em Python 3.11 e 3.13, com testes, build e demo/replay. Execução: https://github.com/gabrielassisp/lakehouse-vendas-gcp-databricks/actions/runs/43768392569

## GCP Sandbox: executado e conferido

- Projeto `SEU_PROJETO_GCP` sem conta de faturamento vinculada, conforme console.
- Dataset `portfolio_vendas` e tabela `raw_events` criados com oito eventos fictícios; expiração padrão em 60 dias.
- DDL e consultas concluídas com SUCCESS. Totais JSON observados: `silver_rows=4`, `tombstones=1`, `active_sales=3`, `revenue=250`.
- Fonte exportada do console, salva localmente e conferida contra o contrato original. Arquivo e hashes em `data/gcp_export/`.
- Notebook de transferência manual importado: WORKSPACE_DATABRICKS_PRIVADO
- Job de demonstração criado: WORKSPACE_DATABRICKS_PRIVADO

## Transferência manual GCP → Databricks: executada

- Notebook 04 concluiu as três células de código com sucesso.
- Volume: `/Volumes/workspace/default/vendas_input/gcp_incoming/events.jsonl`.
- Schemas separados `workspace.vendas_gcp_bronze`, `workspace.vendas_gcp_silver`, `workspace.vendas_gcp_gold`.
- Métricas observadas: `input_rows=8`, `silver_rows=4`, `active_sales=3`.
- Assert da receita: `25000` centavos; mensagem PASS exibida no notebook.
- A origem real foi o arquivo exportado do BigQuery Sandbox. Transferência manual, sem credenciais embutidas e sem faturamento GCP.

## Job Databricks: executado

- `lakehouse-vendas-demo-validacao`, tarefa `validar_lakehouse`, serverless.
- Execução manual `345489554868210`: status **Succeeded**, duração **2m56s**.
- Evidência: WORKSPACE_DATABRICKS_PRIVADO
- O Job repete a demonstração/testes do notebook 03. Não é uma extração agendada do GCP.

## Ainda não validado


- Ponte GCS → Volume, credenciais e permissões efetivas.
- Terraform plan/apply e custo GCP. Infraestrutura não aplicada.
- Escala, uso de dados reais e disponibilidade de produção.

## Restrição de custo

O usuário autorizou somente uso sem cobrança. Nenhuma conta de faturamento deve ser ativada automaticamente. A região opcional do Terraform é `us-central1`, elegível ao Free Tier do Storage, mas a gratuidade depende de conta elegível, cotas e uso total. Não aplicar o Terraform sem verificar essas condições. Databricks Free Edition usa cotas gratuitas próprias.


Nota da versão para divulgação: WORKSPACE_DATABRICKS_PRIVADO indica um endereço removido. Use seu próprio workspace; este texto preserva o histórico da execução original.
