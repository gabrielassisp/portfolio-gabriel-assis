# Lakehouse de vendas com qualidade e recuperação por replay

Estudo de portfólio de Gabriel Assis. Dados fictícios; execução em BigQuery Sandbox e Databricks Free Edition conferida em 15/11/2026. Material organizado em 21/11/2026.

## Problema

Um total de vendas pode ficar incorreto quando a origem corrige valores, exclui vendas ou entrega eventos fora de ordem. Reprocessar os mesmos arquivos também pode duplicar a receita se a carga apenas inserir linhas.

Este projeto demonstra como conservar a entrada para auditoria, reconstruir o estado atual de cada venda e publicar métricas somente após validar os dados. Ele complementa um projeto profissional on-premises; os resultados deste laboratório não representam impacto financeiro medido em uma empresa.

## Solução executada

```mermaid
flowchart LR
    A[Oito eventos fictícios] --> B[BigQuery Sandbox: raw_events]
    B --> C[Exportação manual JSON]
    C --> D[Volume gerenciado no Databricks]
    D --> E[Bronze Delta: entrada preservada]
    E --> F{Contrato e conflitos}
    F -->|válido| G[Silver Delta: MERGE por venda e versão]
    F -->|inválido| Q[Quarentena e bloqueio da publicação]
    G --> H[Gold: view de vendas ativas]
```

Python concentra o contrato e as regras de normalização. PySpark e Delta executam o processamento no Databricks. Um runner Delta local permite testar as regras e a recuperação sem credenciais cloud. GitHub Actions executa 38 testes, constrói o wheel e repete a demonstração em Python 3.11 e 3.13.

O Job manual no Databricks repete os cenários de validação. A transferência do BigQuery foi demonstrada em um notebook separado; não é realizada automaticamente pelo Job.

## Decisões de engenharia

| Decisão | Motivo e consequência |
|---|---|
| Ordenar por `source_version` de cada venda | A chegada de um evento antigo não desfaz uma correção mais recente. A origem precisa fornecer uma versão confiável. |
| Preservar exclusões como tombstones | Uma venda excluída permanece identificável na Silver e não reaparece quando chega uma versão antiga. A Gold considera apenas vendas ativas. |
| Representar dinheiro em centavos inteiros | Evita imprecisão de ponto flutuante no contrato de entrada. |
| Validar antes da atualização da Silver | Um valor inválido bloqueia o lote e preserva o resultado comercial anterior. |
| Reprocessar o histórico Bronze | Facilita recuperação e detecção de conflitos; tem custo de leitura crescente. Não há checkpoint incremental de arquivos. |
| Usar uma view Gold no Databricks | O resultado reflete a Silver sem manter uma segunda cópia materializada. |
| Exportar manualmente do Sandbox | Permitiu a demonstração entre os ambientes sem ativar faturamento. Automatização dessa transferência permanece uma evolução. |

## Resultados verificáveis

| Cenário | Resultado observado |
|---|---|
| Três vendas iniciais | Receita de R$ 350,00 |
| Correção, exclusão e nova venda | Receita de R$ 250,00; três vendas ativas |
| Chegada de versões antigas | Receita mantida; venda excluída não reapareceu |
| Replay do mesmo arquivo | Contagens Bronze/Silver mantidas em 8/4 |
| Valor negativo | Entrada em quarentena; Silver preservada |
| Exportação do BigQuery processada no Databricks | Oito eventos de entrada; quatro registros Silver; três vendas ativas; receita de R$ 250,00 |
| Job manual | Status Succeeded; duração observada de 2min56s em uma execução |

As evidências e os links de execução estão em [VALIDATION.md](VALIDATION.md). Os 2min56s são uma medição isolada, sem compromisso de latência ou comparação de desempenho.

## O que este projeto demonstra

- Modelagem de estado atual a partir de eventos de negócio.
- Uso de SQL, Python, PySpark, Delta Lake e Unity Catalog.
- Idempotência, tratamento de exclusões e eventos atrasados.
- Regras de qualidade, investigação de falhas e recuperação por reexecução.
- CI com testes e empacotamento; execução cloud validada separadamente.
- Escolha de uma arquitetura compatível com a restrição de custo.

## Limites e próxima evolução

São oito eventos sintéticos, sem benchmark de escala, SLA ou dados de produção. O CI não implanta nem executa o Spark no workspace; não há CD autenticado configurado. A leitura Bronze é completa, e a transação Delta é por tabela, sem transação global entre camadas.

A evolução com maior impacto seria automatizar a transferência com autenticação apropriada, persistir métricas de execução e introduzir checkpoints quando o volume justificar. GCS e Terraform estão preparados como alternativa, mas não foram implantados. O projeto GCP utilizado na demonstração permaneceu sem faturamento vinculado.

## Texto curto para currículo

> Projeto de portfólio: implementei e validei um lakehouse de vendas com Python, PySpark, SQL e Delta Lake no Databricks Free Edition, usando dados fictícios exportados manualmente do BigQuery Sandbox. Modelei as camadas Bronze/Silver/Gold, atualização por versão, exclusões, replay idempotente e bloqueio por qualidade, com 38 testes automatizados em GitHub Actions.

Use esse texto como descrição do laboratório. Diferencie-o da experiência profissional e esteja preparado para explicar e reproduzir as decisões do código.
