# Decisoes, limites e operacao

## Contrato

Uma linha JSON e um evento de venda. source_version e um inteiro crescente **por sale_id**, fornecido pela origem ficticia. A demo nao descobre CDC em APIs arbitrarias; uma API real precisaria fornecer versao/alteracao confiavel ou um mecanismo equivalente.

- UPSERT exige customer_id, channel, sale_date e amount nao negativo com ate duas casas decimais.
- DELETE preserva um tombstone com sua versao. Um evento atrasado de versao menor nao ressuscita a venda.
- event_time exige timezone; ordenacao de negocio usa source_version, nao horario de chegada.
- event_id e imutavel. Mesmo ID com conteudo diferente bloqueia publicacao.
- Mesma venda/versao com conteudo diferente tambem bloqueia. Repeticoes equivalentes sao aceitas.
- Granularidade Silver: uma linha por sale_id, representando estado atual; Bronze conserva os eventos recebidos.
- Gold: receita e quantidade de vendas atualmente ativas por data de venda e canal. Correcoes e exclusoes ajustam resultados de datas passadas; nao representa receita contabil reconhecida nem snapshots historicos de fechamento.
- Dinheiro usa centavos inteiros. A normalizacao e compartilhada pelo runner local e pela UDF Python do Spark.

## Idempotencia e recuperacao

Bronze tem MERGE insert-only por hash do texto recebido; mesmo arquivo reprocessado nao duplica a linha bruta. JSON com espacos diferentes pode gerar outro hash Bronze; a validacao por identidade/versao mantem o estado comercial sem duplicacao.

Silver usa MERGE por sale_id, atualizando somente se source_version for maior. Tombstones nao sao removidos fisicamente. Cada MERGE e transacional na sua tabela Delta. Nao existe transacao atomica global entre Bronze, quarentena, Silver e Gold.

As leituras do historico Bronze sao completas nesta primeira versao, embora a atualizacao Silver seja por MERGE/versionamento. Nao chamar a leitura de incremental com checkpoint. Isso facilita recuperacao apos interrupcoes e deteccao de conflitos, mas nao e o desenho final para historicos muito grandes.

Gold no Databricks e view da Silver; na demo local e tabela Delta materializada. A demo local tem janela entre atualizar Silver e Gold; o teste de queda comprova recuperacao na reexecucao. Nao alegar equivalencia transacional entre as duas implementacoes.

## Qualidade

Lote atual com evento invalido: registra Bronze/quarentena e falha antes de Silver. Eventos invalidos historicos ficam excluidos de futuras transformacoes. Para corrigi-los, publique novo evento valido. A quarentena mantem o raw para auditoria; a razao pode ser recalculada pela mesma normalizacao.

Conflito de identidade ou versao: falha antes da publicacao. Nao editar Bronze para esconder o conflito. Em ambiente de desenvolvimento, use um novo prefixo para reconstruir com a origem corrigida; em producao seria necessario um fluxo explicito de resolucao/auditoria.

## Falhas e evidencias

- Capture logs do Job, versoes Delta e contagens antes/depois de cada cenario.
- Ausencia de arquivo ou entrada vazia deve falhar, nao apagar o destino.
- Meça latencia, tempo por lote, contagem de rejeitados e custo antes de alegar SLA.
- CI roda regras e Delta local; ainda nao executa Spark/Job com sua conta. Faca smoke test no workspace antes de publicar alteracoes de runtime.
- Dados sinteticos apenas. Nao foram utilizados clientes, credenciais ou arquivos do mini servidor corporativo.

## Melhorias posteriores com justificativa

Checkpoint de arquivos, controle de versoes compacto, testes Spark no workspace, metricas persistentes, carga de API real e deploy autenticado por federacao. Kafka so faria sentido para uma necessidade definida de eventos/consumidores; nao e necessario para os cenarios batch deste projeto.
