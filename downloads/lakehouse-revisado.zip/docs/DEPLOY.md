# Executar no Databricks Free Edition e integrar com GCP

## O que esta pronto e o que depende da sua conta

O notebook PySpark/Delta, o Job manual e a transferência por arquivo do BigQuery Sandbox já foram executados na conta. Consulte [a versão gratuita sem faturamento](FREE_SANDBOX.md) e [as evidências](VALIDATION.md). Este roteiro mantém também a alternativa GCS, que não foi implantada e não deve ser aplicada sem verificar faturamento, cotas e custos.

A Free Edition e serverless e restringe acesso de saida. Por isso a demonstracao inicial usa um volume **gerenciado** Unity Catalog. Nao presume que uma external location GCS ou rede personalizada esteja disponivel. A ponte e executada **no seu computador**, lendo GCS e enviando arquivos pela API Files do Databricks. Nao e streaming: e sincronizacao batch explicita.

## 1. Demonstracao Free Edition sem GCP

1. No Catalog Explorer, escolha um catalogo onde voce possa criar schemas. Nos exemplos, usamos workspace; confirme o nome real.
2. Em SQL, crie o volume de entrada:

```sql
CREATE SCHEMA IF NOT EXISTS workspace.default;
CREATE VOLUME IF NOT EXISTS workspace.default.vendas_input;
```

3. Pelo Catalog Explorer, crie as pastas incoming e packages no volume. Envie os tres JSONL de data/sample para incoming e o wheel de dist para packages. Envie apenas o primeiro arquivo se quiser demonstrar a evolucao passo a passo.
4. Importe notebooks/01_demo_free.py para o workspace. Ajuste o caminho do wheel na primeira celula, o catalogo e o caminho dos dados. Execute com compute serverless.
5. A primeira celula instala somente o wheel do projeto, sem as dependencias opcionais locais. O notebook reinicia o Python e reutiliza o Spark fornecido pelo Databricks.
6. Rode as consultas de sql/dashboard.sql. Os tres arquivos juntos devem produzir tres vendas ativas e receita de R$ 250,00. Execute novamente: os valores devem permanecer iguais.

Para testar falha, envie data/invalid/negative.jsonl separadamente e execute usando o caminho exato desse arquivo. A execucao deve falhar apos gravar a Bronze/quarentena e antes de alterar Silver. Depois, retire o arquivo invalido da pasta de entrada ativa ou aponte novamente para os arquivos validos. Nao envie o arquivo invalido junto ao diretorio inteiro da demo normal.

## 2. Job reproduzivel com bundle

Instale a Databricks CLI oficial e autentique localmente:

```sh
databricks auth login --host https://SEU_WORKSPACE
python -m pip install -e '.[dev]'
databricks bundle validate --target dev --var 'catalog=workspace,input_path=/Volumes/workspace/default/vendas_input/incoming/*.jsonl'
databricks bundle deploy --target dev --var 'catalog=workspace,input_path=/Volumes/workspace/default/vendas_input/incoming/*.jsonl'
databricks bundle run --target dev vendas --var 'catalog=workspace,input_path=/Volumes/workspace/default/vendas_input/incoming/*.jsonl'
```

Validar, publicar e executar sao passos diferentes. O bundle nao tem agenda automatica. A disponibilidade da API/versao do ambiente serverless deve ser confirmada no workspace; o notebook permite a mesma execucao sem depender da CLI. O Job limita concorrencia a um e tem timeout de 30 minutos. Outros escritores externos nao sao coordenados por esse limite.

## 3. GCS como origem com ponte externa

Requer projeto GCP com Cloud Storage habilitado e autenticacao local autorizada. Armazenamento, operacoes e transferencia podem gerar cobranca; nenhum comando abaixo foi executado automaticamente.

Se voce ja tem bucket, reutilize-o. Se quiser criar um bucket demonstrativo com Terraform, preencha infra/terraform.tfvars.example em um arquivo local terraform.tfvars, revise terraform plan e somente depois decida aplicar. Nao versionar tfvars, state ou credenciais. Nao usar o mesmo bucket de producao.

```sh
gcloud auth application-default login
gcloud storage cp data/sample/*.jsonl gs://SEU_BUCKET/incoming/
python -m pip install -e '.[bridge]'
python tools/sync_gcs_to_volume.py --bucket SEU_BUCKET --prefix incoming/ --volume-path /Volumes/workspace/default/vendas_input/incoming
```

O upload gcloud usa sua conta ativa; a biblioteca Storage usa Application Default Credentials. Garanta que ambas tenham acesso ao projeto correto. A ponte usa autenticacao do perfil DEFAULT da Databricks CLI/SDK. Para outro perfil, passe --profile NOME. Use identidades dedicadas e federacao/impersonacao quando configurar automacao; nao copie chaves JSON para o repositorio.

A service account opcional do Terraform recebe somente leitura dos objetos do bucket. Sua criacao nao autoriza automaticamente seu PC a representa-la: isso exige configuracao separada de IAM. A ponte nao exige essa service account para a demo interativa com ADC do proprio usuario.

Cada arquivo no destino recebe nome derivado do bucket, caminho e geracao GCS. Objetos existentes sao ignorados; novas geracoes viram novos arquivos. A leitura usa a geracao esperada para evitar corrida com sobrescrita na origem. Limite de 10 MiB por arquivo, adequado a esta demonstracao. Exclusao de objeto GCS nao significa exclusao de venda: a exclusao de negocio e um evento DELETE.

Rode novamente o notebook/Job apos a ponte. Agora existe um percurso GCS -> ponte -> Volume -> Databricks -> Gold. Registre essa execucao antes de afirmar no portfolio que a integracao foi implantada.

## Evolucao para workspace Databricks on GCP

Em workspace com recursos/permissoes adequados, substitua a ponte por external volume/localizacao GCS governada pelo Unity Catalog. Configure storage credential, service account e IAM no bucket conforme a documentacao oficial. Leia pelo caminho do volume externo; o pipeline continua recebendo /Volumes/.... Prefira bucket e workspace na mesma regiao. Isso e uma alternativa de implantacao, nao um componente ja testado aqui.

## Documentacao oficial usada

- https://docs.databricks.com/gcp/en/getting-started/free-edition-limitations
- https://docs.databricks.com/gcp/en/connect/unity-catalog/cloud-storage/external-locations-gcs
- https://docs.databricks.com/gcp/en/dev-tools/bundles/examples
- https://docs.databricks.com/gcp/en/delta/merge
